# 加载必要的包
library(readxl)        # 用于读取Excel文件
library(ggplot2)       # 用于绘图
library(eulerr)        # 用于绘制韦恩图
library(patchwork)     # 用于组合多个图形

# 读取数据
data <- read_excel("D:/R Graph Data/R Graph/Two-factor analysis-Cadmium-Fish.xlsx")

# 确保分类变量为因子类型
data$Species <- as.factor(data$Species)
data$Country <- as.factor(data$Country)

# 双因素方差分析
aov_model <- aov(Value ~ Species + Country + Species:Country, data = data)

# 输出方差分析结果
anova_summary <- summary(aov_model)
print(anova_summary)

# 提取方差分析结果中的p值
anova_table <- as.data.frame(anova(aov_model))
p_values <- anova_table$`Pr(>F)`[1:3]  # 提取前三项的p值

# 修正贡献百分比的计算，确保总和为100%
total_ss <- sum(anova_table$`Sum Sq`[1:3])  # 仅考虑主要因素和交互作用的总平方和
partition_result <- data.frame(
  Factor = c("Species", "Country", "Species:Country"),
  Contribution = anova_table$`Sum Sq`[1:3] / total_ss * 100,  # 贡献百分比
  p_value = p_values
)

# 添加显著性标记
partition_result$Significance <- cut(
  partition_result$p_value,
  breaks = c(-Inf, 0.001, 0.01, 0.05, Inf),
  labels = c("***", "**", "*", "ns"),
  right = FALSE
)

# 绘制韦恩图
russian_doll <- euler(c(
  "Species" = round(partition_result$Contribution[1], 2),
  "Country" = round(partition_result$Contribution[2], 2),
  "Species&Country" = round(partition_result$Contribution[3], 2)
), shape = "ellipse")

p1 <- plot(russian_doll, 
           fills = list(fill = c("#32A1CD", "#FE9A35", "#00B654"), alpha = 0.6), 
           quantities = list(type = "counts", fontsize = 30),
           labels = list(fontsize = 30))

# 绘制柱形图
partition_result$Factor <- factor(partition_result$Factor, levels = c("Species", "Country", "Species:Country"))

p2 <- ggplot(partition_result, aes(x = Factor, y = Contribution)) +
  geom_bar(aes(fill = Factor), stat = "identity", color = "black", size = 0.8, 
           position = position_dodge(0.9), width = 0.7, alpha = 0.6) +
  geom_text(aes(label = Significance, y = Contribution + 3), color = "black", size = 15, fontface = "bold") +
  scale_y_continuous(breaks = seq(0, 50, 10), limits = c(0, 55)) +
  scale_fill_manual(values = c("#32A1CD", "#FE9A35", "#00B654")) +
  coord_flip() +
  theme_classic() +
  theme(
    text = element_text(family = "Times New Roman", size = 40),
    axis.text.y = element_text(margin = unit(rep(0.5, 4), "cm")),
    axis.ticks.length = unit(-0.25, "cm")
  ) +
  labs(x = "Factors", y = "Contribution (%)", fill = "Factors") +
  theme(legend.position = 'none')

# 组合图形
final_plot <- p2 + p1 + plot_layout(ncol = 2, widths = c(1, 1))

# 保存图形
output_path <- "D:/R Graph Data/R Graph/镉小小鱼_combined.svg"
ggsave(output_path, plot = final_plot, width = 12, height = 6)

# 在 RStudio 中显示组合图
print(final_plot)

