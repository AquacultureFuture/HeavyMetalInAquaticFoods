library(readxl)
library(ggplot2)
library(rnaturalearth)
library(sf)
library(dplyr)
library(patchwork)
library(scales)
library(viridis)
library(RColorBrewer)
library(showtext) # 用于嵌入字体

# 加载字体
font_add_google("Roboto", "roboto")
showtext_auto()

# 读取数据
data_path <- "D:/R Graph Data/R Graph/Fig.6EDI.xlsx" # Ensure the path is correct
df <- read_excel(data_path)

# 加载世界地图，移除南极洲
world <- ne_countries(scale = "medium", returnclass = "sf") %>%
  filter(name != "Antarctica")

# 初始化图形列表
plots <- list()

# 从列名中提取不同的指标类型（例如Total, Cadmium等）
indicators <- unique(gsub("EDI_BAU_(.*)", "\\1", names(df)[grepl("BAU", names(df))]))

# 对每个指标类型执行操作
for (indicator in indicators) {
  # 为该指标类型找到所有相关的列
  indicator_cols <- grep(indicator, names(df), value = TRUE)
  
  # 确定BAU列并计算颜色映射的最大和最小值
  bau_cols <- grep("BAU", indicator_cols, value = TRUE)
  bau_col <- bau_cols[1]  # Use only the first BAU column if multiple are found
  max_val <- max(df[[bau_col]], na.rm = TRUE)
  min_val <- min(df[[bau_col]], na.rm = TRUE)
  
  # 定义颜色映射
  color_values <- scale_fill_gradientn(
    colours = brewer.pal(9, "YlGnBu"),
    limits = c(min_val, max_val),
    name = "",
    labels = scales::percent
  )
  
  # 生成地图
  for (col in indicator_cols) {
    merged_data <- world %>%
      left_join(df, by = c("name" = "Country")) %>%
      select(geometry, all_of(col))
    
    # Ensure values are within range
    merged_data[[col]] <- pmax(pmin(merged_data[[col]], max_val), min_val)
    
    p <- ggplot(merged_data) +
      geom_sf(aes(fill = !!rlang::sym(col)), na.rm = TRUE) +
      color_values +
      labs(title = col) +
      theme_minimal(base_family = "roboto") +
      theme(
        panel.border = element_rect(colour = "black", fill = NA, size = 1), # 添加边框
        axis.text = element_blank(), # 去除经度和纬度的数值
        axis.ticks = element_line(colour = "black", size = 0.8), # 突出显示经度的刻度
        axis.ticks.length = unit(0.15, "cm"),
        axis.line = element_blank(),
        panel.grid = element_blank(), # 去除虚网格线
        legend.position = c(0.1, 0.43), # 图例放在左下角
        legend.key.size = unit(0.5, "cm"), # 缩小图例大小
        legend.text = element_text(size = 8),
        legend.title = element_text(size = 8),
        plot.title = element_text(size = 12)
      )
    
    plots[[col]] <- p
  }
}

# 使用 patchwork 组合图形，每行显示3个
plot_grid <- wrap_plots(plots, ncol = 3)

# 显示组合后的图形
print(plot_grid)

# 保存图像为SVG格式，使用 ggsave
showtext_auto() # 确保字体嵌入
ggsave("D:/R Graph Data/R Graph/Fig.6EDIcombined_plot2.svg", plot = plot_grid, width = 16, height = 12, device = "svg")
showtext_auto(FALSE) # 禁用字体嵌入


